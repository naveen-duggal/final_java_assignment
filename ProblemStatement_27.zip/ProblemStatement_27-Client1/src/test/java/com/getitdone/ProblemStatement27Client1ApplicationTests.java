package com.getitdone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProblemStatement27Client1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
