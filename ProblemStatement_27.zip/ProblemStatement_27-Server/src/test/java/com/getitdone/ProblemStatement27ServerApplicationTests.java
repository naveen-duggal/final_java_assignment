package com.getitdone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProblemStatement27ServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
