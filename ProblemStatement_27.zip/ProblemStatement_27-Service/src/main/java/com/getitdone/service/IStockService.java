package com.getitdone.service;

public interface IStockService {
	
	public double getStockPrice(String companyName);

}
